import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Wrench, Zap, Droplets, Lightbulb, Building2, ShieldCheck, CheckCircle2,
  Phone, Mail, MapPin, MessageCircle, CreditCard, Copy, ArrowRight, Menu, X,
  Bot, CalendarDays, Send, Star, Clock
} from "lucide-react";
import "./styles.css";

const PHONE = "03021822160";
const DISPLAY_PHONE = "0302 1822160";
const EMAIL = "jaidykhan9@gmail.com";
const WHATSAPP = `https://wa.me/92${PHONE}`;
const IBAN = "PK59BAHL2011009500475401";
const ACCOUNT_TITLE = "Junaid Farooq";

const services = [
  ["Electrical Services", Zap, "House wiring, fault finding, lights, switches, sockets, fans and maintenance.", "/images/electrical-work.jpg"],
  ["Plumbing Services", Droplets, "Pipework, leak repairs, bathroom and kitchen plumbing, drainage and maintenance.", "/images/plumbing-work.jpg"],
  ["General Maintenance", Wrench, "Practical repairs and maintenance for homes, shops and businesses.", "/images/gallery-construction.jpg"],
  ["Lighting & Fixtures", Lightbulb, "Installation, replacement, troubleshooting and lighting upgrades.", "/images/gallery-lighting.jpg"],
  ["Installation & Repair", Wrench, "Professional installation and repair for common property needs.", "/images/gallery-electrical.jpg"],
  ["Commercial Maintenance", Building2, "Reliable support for shops, offices, buildings and larger properties.", "/images/cta-worksite.jpg"]
];

const gallery = [
  ["Electrical Installation", "/images/gallery-electrical.jpg"],
  ["Plumbing Installation", "/images/gallery-plumbing.jpg"],
  ["Bathroom Plumbing", "/images/gallery-bathroom.jpg"],
  ["Kitchen Plumbing", "/images/gallery-kitchen.jpg"],
  ["Construction Site Work", "/images/gallery-construction.jpg"],
  ["Lighting Installation", "/images/gallery-lighting.jpg"],
  ["Electrical Repair", "/images/electrical-work.jpg"],
  ["Plumbing & Pipework", "/images/plumbing-work.jpg"],
  ["Professional Worksite", "/images/cta-worksite.jpg"]
];

function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [messages, setMessages] = useState([{ role: "assistant", text: "Hi! I’m JD Assistant 👋 Ask me about services, Mansehra coverage, bookings, quotations or payments." }]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [bookingSent, setBookingSent] = useState(false);
  const chatEnd = useRef(null);

  useEffect(() => { chatEnd.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, chatLoading]);

  const copyIban = async () => {
    try { await navigator.clipboard.writeText(IBAN); setCopied(true); setTimeout(() => setCopied(false), 1800); } catch {}
  };

  const sendBooking = (e) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = data.get("name");
    const phone = data.get("phone");
    const service = data.get("service");
    const datetime = data.get("datetime");
    const details = data.get("details");
    const text = `New website booking\nName: ${name}\nPhone: ${phone}\nService: ${service}\nPreferred date/time: ${datetime}\nDetails: ${details}`;
    window.open(`${WHATSAPP}?text=${encodeURIComponent(text)}`, "_blank", "noopener,noreferrer");
    setBookingSent(true);
    e.currentTarget.reset();
  };

  const sendChat = (text = chatInput) => {
    const trimmed = String(text || "").trim();
    if (!trimmed || chatLoading) return;

    setChatInput("");
    setMessages(prev => [...prev, { role: "user", text: trimmed }]);
    setChatLoading(true);

    const x = trimmed.toLowerCase().replace(/[?!.,]/g, " ").replace(/\s+/g, " ").trim();

    const rules = [
      { test: /^(hi|hello|hey|salam|assalam|aoa)\b/, reply: "Hello! 👋 I’m JD Assistant. Ask me about services, prices, service areas, bookings, payments, or how to contact JD." },
      { test: /how (much|many)|price|cost|rate|charges|fee|estimate|quote|quotation|budget/, reply: "Pricing depends on the job, materials and location. I don’t want to guess and give you the wrong amount. For a quote, tap “Talk directly to JD” and send the job details or use the booking form." },
      { test: /payment|pay|iban|bank|transfer|jazzcash|easypaisa|account/, reply: `For approved jobs, bank-transfer details are shown in the Payment section. Bank: Bank Al Habib • Account title: ${ACCOUNT_TITLE} • IBAN: ${IBAN}. For payment confirmation, contact JD directly so the payment can be matched to your job.` },
      { test: /book|booking|appointment|schedule|visit|service request|hire/, reply: "Sure. Use the Booking Request form, or tap “Talk directly to JD” to message JD on WhatsApp. Include your name, phone, area, service and preferred time." },
      { test: /emergency|urgent|asap|now|immediately/, reply: `For an urgent electrical or plumbing issue, call JD at ${DISPLAY_PHONE} or use WhatsApp. Availability depends on the location and current workload.` },
      { test: /service|what do you do|offer|provide/, reply: "JD provides electrical services, plumbing services, lighting and fixtures, installation and repair, general maintenance, and commercial maintenance." },
      { test: /electric|electrical|wiring|switch|socket|light|lighting|fan|fault|breaker|power/, reply: "Electrical work includes house wiring, fault finding, switches, sockets, lights, fans, fixtures, installation, repair and maintenance." },
      { test: /plumb|plumbing|pipe|leak|bathroom|kitchen|drain|tap|water|toilet/, reply: "Plumbing work includes pipework, water supply, leak repairs, taps and fittings, bathroom and kitchen plumbing, drainage and maintenance." },
      { test: /commercial|shop|office|business|building|project|new house|complete house|construction/, reply: "Yes. JD supports shops, offices, buildings and larger property projects. For commercial or large work, send the scope and location to JD for a proper quotation." },
      { test: /where|area|mansehra|ghazikot|location|near|far|coverage/, reply: "JD is based in Ghazikot Township, Mansehra and serves Mansehra and surrounding areas. Send your exact area on WhatsApp to confirm availability." },
      { test: /contact|phone|call|whatsapp|email|number/, reply: `You can call ${DISPLAY_PHONE}, message JD on WhatsApp, or email ${EMAIL}. The Contact section also has the booking form.` },
      { test: /hour|open|timing|time|available|working/, reply: "For the most accurate availability, call or WhatsApp JD at the contact details on this page. Service timing can vary by job and location." },
      { test: /warranty|guarantee|quality/, reply: "JD aims to provide reliable professional work. Warranty or guarantee terms can vary by job and materials, so please confirm them with JD before the work starts." },
      { test: /about|who are you|who is jd|company/, reply: "JD Electrical & Plumbing Works is a local Mansehra service business for electrical, plumbing and general maintenance work in homes, shops and businesses." },
      { test: /thank|thanks|great|ok|okay|nice/, reply: "You’re welcome! 😊 If you’re ready, I can help you choose the right service or you can contact JD directly." },
      { test: /help|question|can you|what can you/, reply: "I can answer questions about JD’s services, electrical/plumbing work, service area, contact details, payments, bookings, quotations and general job information." }
    ];

    const match = rules.find(r => r.test.test(x));
    const reply = match?.reply || "I can help with JD’s electrical, plumbing and maintenance services, service area, bookings, payments, quotations and contact details. If your question is more specific, send it in one sentence and I’ll do my best to answer from the website information.";

    window.setTimeout(() => {
      setMessages(prev => [...prev, { role: "assistant", text: reply }]);
      setChatLoading(false);
    }, 450);
  };

  return <div>
    <div className="topbar">
      <span><MapPin size={14}/> Ghazikot Township, Mansehra</span><span><Mail size={14}/> {EMAIL}</span><span><Phone size={14}/> {DISPLAY_PHONE}</span>
    </div>
    <header className="nav">
      <a className="brand" href="#home"><span className="brand-mark">JD</span><span>Electrical <b>&</b> Plumbing Works<small>Reliable • Professional • Mansehra</small></span></a>
      <button className="menu-btn" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Toggle menu">{mobileOpen ? <X/> : <Menu/>}</button>
      <nav className={mobileOpen ? "nav-links open" : "nav-links"}>
        {["services","work","payment","about","contact"].map(id => <a key={id} href={`#${id}`} onClick={() => setMobileOpen(false)}>{id[0].toUpperCase()+id.slice(1)}</a>)}
        <a className="nav-cta" href="#contact">Book a Service <ArrowRight size={16}/></a>
      </nav>
    </header>

    <main id="home">
      <section className="hero hero-image">
        <div className="hero-copy"><div className="eyebrow">JD ELECTRICAL & PLUMBING WORKS</div><h1>Professional Electrical & Plumbing Services in <span>Mansehra</span></h1>
          <p>Reliable electrical and plumbing solutions for homes, shops and businesses in Ghazikot Township, Mansehra and surrounding areas.</p>
          <div className="hero-actions"><a className="btn primary" href={`tel:+92${PHONE}`}><Phone size={18}/> Call Now</a><a className="btn glass" href={WHATSAPP} target="_blank" rel="noreferrer"><MessageCircle size={18}/> WhatsApp Us</a></div>
          <div className="trust-row"><span><CheckCircle2/> Electrical Services</span><span><CheckCircle2/> Plumbing Services</span><span><CheckCircle2/> Residential & Commercial</span></div>
        </div>
        <div className="hero-visual"><img src="/images/hero-electrician.jpg" alt="AI-generated electrician working on an electrical panel"/></div>
      </section>

      <section className="trust-strip"><div><ShieldCheck/><b>Reliable Work</b><small>Professional local service</small></div><div><Clock/><b>Responsive Service</b><small>Call or WhatsApp directly</small></div><div><MapPin/><b>Local Service</b><small>Mansehra & surrounding areas</small></div><div><MessageCircle/><b>Easy to Contact</b><small>Quick booking support</small></div></section>

      <section className="section" id="services"><div className="eyebrow">OUR SERVICES</div><h2>Electrical & Plumbing Services</h2><div className="service-grid">{services.map(([title, Icon, text, image]) => <article className="service-card" key={title}><img src={image} alt={`AI-generated ${title.toLowerCase()} work`} /><div className="service-content"><div className="icon-box"><Icon/></div><h3>{title}</h3><p>{text}</p><a className="text-link" href="#contact">Request service <ArrowRight size={15}/></a></div></article>)}</div></section>

      <section className="payment-banner" id="payment"><div><div className="eyebrow">PAYMENT</div><h2>Bank Transfer / Online Payment</h2><p>For approved jobs and payment confirmation, use the details below and contact JD directly.</p></div><div className="bank-box"><b>Bank Al Habib</b><span>Account Title: {ACCOUNT_TITLE}</span><span>IBAN: <strong>{IBAN}</strong></span><button className="btn light" onClick={copyIban}><Copy size={16}/> {copied ? "Copied" : "Copy IBAN"}</button></div><a className="btn wa" href={`${WHATSAPP}?text=${encodeURIComponent("Hello JD, I want payment details / payment confirmation.")}`} target="_blank" rel="noreferrer"><MessageCircle size={17}/> Payment Help</a></section>

      <section className="section" id="work"><div className="eyebrow">OUR WORK</div><h2>Recent Work</h2><div className="gallery">{gallery.map(([title, image]) => <figure key={title}><img src={image} alt={`AI-generated ${title}`} /><figcaption>{title}</figcaption></figure>)}</div><p className="note">These visuals are AI-generated website imagery. Replace them with your real project photos as you collect them for stronger customer trust.</p></section>

      <section className="process"><div className="eyebrow">HOW IT WORKS</div><h2>Getting Started Is Easy</h2><div className="steps"><div><b>01</b><h3>Contact JD</h3><p>Call, WhatsApp or use the booking form.</p></div><div><b>02</b><h3>Discuss the Job</h3><p>Share the problem, location and timing.</p></div><div><b>03</b><h3>Confirm the Work</h3><p>JD reviews larger jobs and confirms the service.</p></div></div></section>

      <section className="about section" id="about"><img src="/images/about-team.jpg" alt="AI-generated electrical and plumbing service team"/><div><div className="eyebrow">ABOUT JD</div><h2>Your Local Electrical & Plumbing Partner</h2><p>JD Electrical & Plumbing Works provides electrical, plumbing and general maintenance services for homes, shops and businesses in Mansehra and nearby areas.</p><p>For large projects, quotations and payment matters, the website assistant sends customers directly to JD so the details can be discussed properly.</p></div></section>

      <section className="section reviews"><div className="eyebrow">CUSTOMER FEEDBACK</div><h2>What Customers Say</h2><div className="review-grid">{["Excellent work and very professional. Highly recommended.","Quick response and helpful service. Will definitely call again.","Professional, reliable and friendly service."] .map((text,i)=><blockquote key={i}><div className="stars">★★★★★</div><p>“{text}”</p><b>— Customer, Mansehra</b></blockquote>)}</div><p className="note">Customer reviews will be added here as genuine feedback is collected.</p></section>

      <section className="area"><div><div className="eyebrow">SERVICE AREA</div><h2>Serving Mansehra & Surrounding Areas</h2><p>Ghazikot Township, Mansehra and nearby locations. Contact JD to confirm availability.</p></div><img src="/images/mansehra.jpg" alt="AI-generated Mansehra landscape"/></section>

      <section className="contact section" id="contact"><div><div className="eyebrow">BOOK A SERVICE</div><h2>Tell JD What You Need</h2><p>Small questions can be handled by the assistant. Payments, quotations and large projects are handed to JD directly.</p><div className="contact-list"><span><Phone/> {DISPLAY_PHONE}</span><span><Mail/> {EMAIL}</span><span><MapPin/> Ghazikot Township, Mansehra</span></div></div><form className="form-card" onSubmit={sendBooking}><h3>Booking Request</h3><input name="name" required placeholder="Full name"/><input name="phone" required placeholder="Phone / WhatsApp"/><select name="service" required defaultValue=""><option value="" disabled>Select service</option><option>Electrical</option><option>Plumbing</option><option>General Maintenance</option><option>Large Project / Quotation</option><option>Payment Help</option><option>Other</option></select><input name="datetime" required placeholder="Preferred date & time"/><textarea name="details" required placeholder="Describe the job or project"></textarea><button className="btn primary full" type="submit"><Send size={17}/> Send Booking to JD</button>{bookingSent && <p className="success">WhatsApp opened with the booking details. Press Send to deliver it to JD.</p>}</form></section>
    </main>

    <footer><div><b className="footer-title">JD</b><p>Electrical & Plumbing Works</p></div><div><h4>Quick Links</h4><a href="#services">Services</a><a href="#work">Our Work</a><a href="#payment">Payment</a><a href="#contact">Contact</a></div><div><h4>Contact</h4><a href={`tel:+92${PHONE}`}>{DISPLAY_PHONE}</a><a href={WHATSAPP} target="_blank" rel="noreferrer">WhatsApp</a><span>Mansehra & surrounding areas</span></div><div><h4>Follow</h4><span>Facebook • Instagram • YouTube</span></div></footer>

    <button className="chat-toggle" onClick={() => setChatOpen(v => !v)} aria-label="Open JD Assistant"><Bot/></button>
    {chatOpen && <div className="chatbox"><div className="chat-head"><div><b>JD Assistant</b><small aria-live="polite">{chatLoading ? "Thinking…" : "Online • questions & answers"}</small></div><button onClick={() => setChatOpen(false)}><X/></button></div><div className="chat-messages" aria-live="polite">{messages.map((m,i)=><div key={i} className={`chat-msg ${m.role}`}>{m.text}</div>)}{chatLoading && <div className="chat-msg assistant">Thinking…</div>}<div ref={chatEnd}/></div><div className="quick"><button onClick={() => sendChat("What services do you provide?")}>Services</button><button onClick={() => sendChat("I need a quotation")}>Quotation</button><button onClick={() => sendChat("I want to make a payment")}>Payment</button><button onClick={() => sendChat("I want to book a service")}>Book</button></div><form onSubmit={e=>{e.preventDefault();sendChat()}} className="chat-form">
          <input value={chatInput} onChange={e=>setChatInput(e.target.value)} placeholder="Ask JD Assistant…" aria-label="Ask JD Assistant" autoComplete="off"/>
          <button type="submit" disabled={chatLoading || !chatInput.trim()} aria-label="Send question"><Send size={17}/></button>
        </form><a className="chat-direct" href={WHATSAPP} target="_blank" rel="noreferrer"><MessageCircle size={16}/> Talk directly to JD</a></div>}
    <div className="mobile-bar"><a href={`tel:+92${PHONE}`}>📞 Call</a><a href={WHATSAPP} target="_blank" rel="noreferrer">💬 WhatsApp</a></div>
  </div>;
}

createRoot(document.getElementById("root")).render(<App/>);
