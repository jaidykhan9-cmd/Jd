# JD Electrical & Plumbing Works — updated React website

This package updates the supplied React project with the requested business features.

## Included
- AI-style JD Assistant that works immediately in the browser for common conversations.
- Automatic handoff to JD WhatsApp for payments, quotations and large projects.
- Booking form with a pre-filled WhatsApp booking message.
- Bank Al Habib payment section and Copy IBAN button.
- AI-generated visual imagery in `public/images/`.
- Responsive mobile design.
- Call + WhatsApp CTAs.
- Electrical, plumbing and maintenance service sections.
- Recent-work gallery.
- Mansehra service area.
- Testimonials and contact sections.

## Important
The chatbot is deliberately implemented without a client-side API key, so it does not break when deployed to Netlify without an AI provider account. It uses a local conversational assistant for small questions and direct WhatsApp handoff for high-value/sensitive requests.

If you want a true generative AI model later, add a secure server-side endpoint and provider API key via Netlify environment variables. Never put an API key in `src/main.jsx`.

## Booking notification
The booking form opens WhatsApp with a message addressed to JD. The customer still has to press Send; websites cannot silently send WhatsApp messages from a browser.

## Verify before publishing
- Confirm the phone/WhatsApp number: 0302 1822160.
- Confirm the Bank Al Habib IBAN and account title.
- Replace placeholder reviews with genuine customer reviews.
- Replace AI-generated work images with your real project photos when available.
